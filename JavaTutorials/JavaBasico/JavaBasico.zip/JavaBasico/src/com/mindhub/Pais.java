package com.mindhub;

public enum Pais {
    ESPAÑA,ARGENTINA,ITALIA,FRANCIA,BRASIL,CATALUNYA
}
