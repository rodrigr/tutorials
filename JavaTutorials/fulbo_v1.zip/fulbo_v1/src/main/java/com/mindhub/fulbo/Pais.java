package com.mindhub.fulbo;

public enum Pais {
    ESPAÑA,ARGENTINA,ITALIA,FRANCIA,BRASIL,CATALUNYA
}
