package com.mindhub.fulbo;

public enum Posicion {
    ARQ,DEF,MED,DEL
}
