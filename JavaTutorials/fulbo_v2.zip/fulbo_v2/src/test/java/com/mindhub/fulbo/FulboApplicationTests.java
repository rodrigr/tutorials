package com.mindhub.fulbo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FulboApplicationTests {

	@Test
	void contextLoads() {
	}

}
